datasets_dir = '/home/user/data/datasets'
results_base_dir = '/home/user/data/projects_data/dataset_reconstruction/runs/'
models_dir = '/home/user/data/projects_data/dataset_reconstruction/models'